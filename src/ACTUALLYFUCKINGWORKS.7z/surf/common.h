#define MSGBUFSZ 8

void die(char *, ...);
